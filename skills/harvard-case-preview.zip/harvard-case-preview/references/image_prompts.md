# 预习文章配图 · 已验证的提示词（Belden 一期）

这三条提示词的参考价值是"稍微复杂、好看、有手绘感"的画法，**不是**未来案例的固定场景。只复用风格措辞；主体、关系和构图必须从新案例重新提炼，不要只替换一个器物后沿用整套画面。

如果你的图像工具支持参考图，可以附上一两张你喜欢的铅笔线稿作为风格参考。工具返回 `.jpg` 时，可以转成 `.png` 再放进 `<文章名>_配图/`。

## 手绘感修饰词（必带）

```
Hand-drawn pencil sketchbook drawing on pure white background, soft graphite style, no paper texture, no vignette.
… Drawn like an architect's / a naturalist's / a sketchbook study: visible light construction lines, cross-hatching in the shadows, varied pencil pressure, a few loose exploratory strokes, soft 2B graphite, no ink outlines …
```

视角用 `seen from a slight three-quarter angle`，并给 1–2 个前景细节，让画面有层次；不要正立面全对称。

## 头图（16:9）：Baker Library + 线缆卷盘

> Hand-drawn pencil sketchbook drawing on pure white background, soft graphite style, no paper texture, no vignette. Subject: the front facade of Harvard Business School's Baker Library seen from a slight three-quarter angle from the lower left, a neoclassical brick building with a grand portico of six tall columns, a triangular pediment, and a white cupola bell tower with a small dome rising above the roof; a broad flight of stone steps leads up to the central entrance door, which stands ajar. In the foreground at the bottom of the steps sits a large old wooden industrial cable spool, drawn in detail, and a single thick cable unwinds from it and climbs loosely up the stone steps, step by step, disappearing through the open door. Drawn like an architect's sketchbook study: visible light construction lines, cross-hatching in the shadows under the portico and beneath the spool, varied pencil pressure, a few loose exploratory strokes, soft 2B graphite, no ink outlines; the brick walls indicated only by faint grey hatching; the building fades lighter toward its edges. The building occupies about 70% of the frame height with clear margin above and below. Muted Harvard crimson accent only on the small metal connector at the very end of the cable lying on the top step, nothing else is coloured. Lots of white space, refined, no people, no cars, no trees, absolutely no text, numerals, letters, clock numerals, signatures or watermarks.

这张成立，是因为线缆与 Belden 的业务直接相关，"连接"承载了从单件产品到方案的讨论。新案例不要继承"台阶前摆物件 + 进入门口"的动线；重新确定业务主体、关系与视角，哈佛建筑可作为淡远景、局部或边景出现。

## 图 01（4:3）：融化的冰山

> Hand-drawn pencil sketchbook drawing on pure white background, soft graphite style, no paper texture, no vignette. Subject: a single large iceberg seen in cross-section from the side. Above the waterline a small, crisp, solid peak drawn with firm pencil strokes and careful cross-hatched facets, calm and intact. Below the waterline the far larger submerged body of the iceberg, drawn in much lighter, airier graphite hatching, and its underside is visibly hollowed and undercut, eroded into soft scalloped curves with a few thin fragments drifting away from the base. A faint horizontal waterline crosses the whole width of the frame, with a few very light ripple strokes. Drawn like a naturalist's field sketch: visible construction lines, cross-hatching, varied pencil pressure, soft 2B graphite, no ink outlines. Muted Harvard crimson accent only on the thin waterline itself, nothing else is coloured. Centered composition, the iceberg fills about 65% of the frame height, lots of white space, refined, no people, no boats, no animals, absolutely no text, numerals, letters, signatures or watermarks.

## 图 02（4:3）：会议桌上的线缆

> Hand-drawn pencil sketchbook drawing on pure white background, soft graphite style, no paper texture, no vignette. Subject: a long antique wooden boardroom table seen from the near end at a slight three-quarter angle, with about ten elegant high-backed chairs around it, two chairs pulled out as if a meeting just began. On the near end of the table, in the foreground and drawn in detail, lies a single neatly coiled industrial cable with its small metal connector resting on the polished tabletop, out of place among the empty chairs. Behind the far end of the table, very faint and almost dissolving into the white, the suggestion of a tall factory window with a grid of panes. Drawn like a sketchbook study: visible light construction lines, cross-hatching in the shadows under the table and chairs, varied pencil pressure, soft 2B graphite, no ink outlines, the far chairs drawn lighter than the near ones. Muted Harvard crimson accent only on the small metal connector at the end of the coiled cable, nothing else is coloured. Centered composition, lots of white space, refined, no people, no papers, no laptops, absolutely no text, numerals, letters, signatures or watermarks.

设计意图：图 02 的器物与头图是同一件（线缆），把"卖零件的东西"放进"做决策的房间"。新案例只有在同一物件的关系或状态变化能表达另一个判断时才复用；不要为了呼应而重复摆同一物件。

## 新案例的选图记录

生成前，为每张图写明：**本案事实 / 对应段落 → 要表达的判断 → 具体主体及其关系 → 哈佛元素的位置 → 单处红色落点**。再回看最近 3–5 篇配图，说明主体、关系或构图的实质差异。工作记录留在配图说明里，不进入文章正文。

例如，一家医疗账单外包公司的材料可以支持医疗编码、账单审核、拒付返工及回款流程的画面；Belden 的材料可以支持连接器、线缆与设备之间的关系。是否选用还取决于该篇正文的论点。不要推断案例未给出的具体设备、真实票据内容或公司场景。

一张天平只表达"有取舍"，一把钥匙只表达"有控制权"，通常不足以区分本案。若遮住标题后，整张图几乎不改就能放到无关案例中，换一个更具体的方案。

生成后目检：画风、单处红色、无字无人、留白，以及案例相关性和跨案例重复。构图可以不同，视觉风格保持不变。
