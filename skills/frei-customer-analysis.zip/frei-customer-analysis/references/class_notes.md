# 课堂笔记

Joyce Ma 在哈佛商学院 OPM 课堂上记下的笔记，保留原样，括号里是整理时加的说明。这是学员的记录，不是授课者的原话。

- **If you let AI do the first 3, AI makes you dumber.**
  （前三步，也就是选客户、列属性、排序，必须自己做。）
- **If you don't go through the friction of thinking, you will not learn.**
- **Do the exercise for each sector.**
  （每个细分市场、每个运营细分，各画一张图。）
- **Make it second nature to do this exercise.**
  （反复画，画到不用想就会去画。）
- **Have a customer in your mind when you do the exercise!**
- **Do not talk to your customer if you haven't done this.**
  （先在内部画出假设，再去见客户。）
- **Go conceptually.**
  （先抓概念，不要一开始就陷进数据。）
- **Cross every unit and cross every group.**
  （跨部门、跨层级地做，比较大家画出的不同版本。）
- **Learn to "stop winning".**
  - If you win every category, you are too kind: you give your customers too much.
  - But it has to stay in the middle.
    （大多数属性守在持平就好，只在少数几行走到两端。）
